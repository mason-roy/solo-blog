title: 01 Docker 安装配置
date: '2019-10-05 14:18:18'
updated: '2019-10-05 14:34:26'
tags: [Docker, 虚拟化]
permalink: /articles/2019/10/05/1570256298231.html
---
![](https://img.hacpai.com/bing/20180301.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### docker简介        
        Docker 是一个开源的应用容器引擎，基于 Go 语言 并遵从Apache2.0协议开源。     
        Docker 可以让开发者打包他们的应用以及依赖包到一个轻量级、可移植的容器中，然后发布到任何流行的 Linux 机器上，也可以实现虚拟化。                
        容器是完全使用沙箱机制，相互之间不会有任何接口（类似 iPhone 的 app）,更重要的是容器性能开销极低。        

**Docker官方文档 ：https://docs.docker.com/        
Docker官方镜像 ：https://hub.docker.com**

### Docker的应用场景
1. Web 应用的自动化打包和发布。
1. 自动化测试和持续集成、发布。
1. 在服务型环境中部署和调整数据库或其他的后台应用。
1. 从头编译或者扩展现有的 OpenShift 或 Cloud Foundry 平台来搭建自己的 PaaS 环境。

### Docker 的优点
**1、简化程序：**
Docker 让开发者可以打包他们的应用以及依赖包到一个可移植的容器中，然后发布到任何流行的 Linux 机器上，便可以实现虚拟化。Docker改变了虚拟化的方式，使开发者可以直接将自己的成果放入Docker中进行管理。方便快捷已经是 Docker的最大优势，过去需要用数天乃至数周的 任务，在Docker容器的处理下，只需要数秒就能完成。

**2、避免选择恐惧症：**
如果你有选择恐惧症，还是资深患者。那么你可以使用 Docker 打包你的纠结！比如 Docker 镜像；Docker 镜像中包含了运行环境和配置，所以 Docker 可以简化部署多种应用实例工作。比如 Web 应用、后台应用、数据库应用、大数据应用比如 Hadoop 集群、消息队列等等都可以打包成一个镜像部署。

**3、节省开支：**
一方面，云计算时代到来，使开发者不必为了追求效果而配置高额的硬件，Docker 改变了高性能必然高价格的思维定势。Docker 与云的结合，让云空间得到更充分的利用。不仅解决了硬件管理的问题，也改变了虚拟化的方式。

### Docker 架构        
1. Docker 使用客户端-服务器 (C/S) 架构模式，使用远程API来管理和创建Docker容器。        
1. Docker 容器通过 Docker 镜像来创建。        
1. 容器与镜像的关系类似于面向对象编程中的对象与类。

![1.png](https://img.hacpai.com/file/2019/10/1-f97fabd2.png)

![2.png](https://img.hacpai.com/file/2019/10/2-70a05b7a.png)

![3.png](https://img.hacpai.com/file/2019/10/3-7e91f53b.png)




### docker 安装
停止禁用防火墙    
```
systemctl stop firewalld    
systemctl mask firewalld
```


禁用 selinux    
```
sed -i  s/SELINUX=.*/SELINUX=disabled/g  /etc/selinux/config
```

配置 yum 源，安装 docker    
```
yum install docker-engine-1.12.1-1.el7.centos.x86_64.rpm   docker-engine-selinux-1.12.1-1.el7.centos.noarch.rpm
```

启动测试    
```
systemctl start docker    
systemctl enable docker 
```   

ifconfig  启动后可以看见 docker0    
docker version  查看docker版本信息

### 安装busybox镜像    
        busybox是一个集成了一百多个最常用linux命令和工具的软件,他甚至还集成了一个http服务器和一个telnet服务器,而所有这一切功能却只有区区1M左右的大小.我们平时用的那些linux命令就好比是分立式的电子元件,而busybox就好比是一个集成电路,把常用的工具和命令集成压缩在一个可执行文件里,功能基本不变,而大小却小很多倍,在嵌入式linux应用中,busybox有非常广的应用,另外,大多数linux发行版的安装程序中都有busybox的身影,安装linux的时候案ctrl+alt+F2就能得到一个控制台,而这个控制台中的所有命令都是指向busybox的链接.    
        BusyBox就是一柄锋利的瑞士军刀  
        BusyBox集成了各种linux的标准命令，毫不夸张的说，BusyBox可以简单地作为一个linux的发布环境（distribution）。比如，shell,editor（vi,sed,awk等）, 系统管理（coreutils、tar、bzip等），网络应用（ping、ifconfig、wget等），用户管理（login、su、useraddな等），各种服务（crond、syslogd、httpd等），SELinux管理（load_policy、restorecon等）。

搜索 
```
[root@localhost ~]# docker  search  busybox
```

下载 
```
[root@localhost ~]# docker  pull  busybox
```

查看帮助  
```
[root@localhost ~]# docker  help  pull
```

查看镜像  
```
[root@localhost ~]# docker  images
```

导入镜像
```
[root@localhost ~]# docker images    REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE[root@localhost ~]# docker load < busybox.tar    c5183829c43c: Loading layer  1.36 MB/1.36 MB    Loaded image: busybox:latest32.77 kB/1.36 MB[root@localhost ~]# docker images    REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE    busybox             latest              f6e427c148a7        3 weeks ago         1.146 MB
```

导出镜像
```
docker save busybox >busybox.tar
```

利用镜像启动容器
```
docker run -it busybox /bin/shdocker run -it centos /bin/bash
```

查看容器列表
```
docker  ps
```

查看详细信息
```
docker inspect  21d2aeb977cc
docker inspect -f '{.NetworkSettings.IPAddress}' 21d2aeb977ccdocker 
```

### 问题列表，及解答
```
问题：docker run -it  busybox  /bin/bash  报错问题
原因：最后的命令是容器内部命令，容器内，存在才可以执行
可以不指定，不指定启动默认命令
```

```
问题：docker run -it  centos  退出后，配置全部丢失
原因：run 启动的是新的容器，老的容器退出后就停止了
启动管理一个老的容器可以使用 docker start|stop|restart
```

```
问题：老容器启动以后，怎么在进入？
docker  exec -it  容器id  /bin/bash
docker  attach    容器id

exec 与 attach 的区别
exec     单独启动命令运行，与容器启动的终端无关
attach  不启动新的命令，直接连接 console 终端
exec     退出不会影响容器的运行
attach  退出后，容器结束
```

```
问题：如果我使用attach 连接容器后，怎么才能不结束容器？
解决方法：把容器放后台，使用快捷键 ctrl + pq
```

```
问题：attach 为什么退出后，容器会结束？
因为 attach 连接进容器的 pid 1 的进程，当 attach 结束时候，pid 为 1 的进程被结束所有整个容器被销毁
```

```
问题：docker run -it  nginx  没响应？
因为 nginx 启动的默认 cmd 时 nginx daemon，该进程不是一个交互式的进程
```

