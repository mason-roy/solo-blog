title: grafana 6.4.3 结合zabbix 4.0.13 展示监控数据
date: '2019-10-28 12:00:59'
updated: '2019-10-28 16:24:11'
tags: [grafana]
permalink: /articles/2019/10/28/1572235259816.html
---
grafana 6.4.3简介：
      grafana 是一款基于go编写的开源可视化监控和分析工具，支持多种数据源，并且支持告警功能。

官网地址： [https://www.grafana.com/](https://grafana.com/)

 **开始安装grafana：**

1.1 配置grafana yum源
 wget https://dl.grafana.com/oss/release/grafana-6.4.3-1.x86_64.rpm

1.2 使用yum安装grafana并启动grafana-server
yum -y  localinstall grafana-6.4.3-1.x86_64.rpm
systemctl start grafana-server
systemctl enable grafana-server

1.3 下载zabbix插件，并添加zabbix插件到granafa，重启grafana-server

官网插件地址：
 https://grafana.com/grafana/plugins
grafana-cli plugins install alexanderzobnin-zabbix-app  
 systemctl restart grafana-server

1.4 添加mysql数据源和zabbix插件
因为grafana需要读取数据库获取数据源，故需先配置mysql数据源
点击create your fast data source >> 找到Mysql，点击select进入数据源配置界面，添加配置 >> 点击Save & Test
![image20191025160355124.png](https://img.hacpai.com/file/2019/10/image20191025160355124-5ce1eb31.png)

![image20191025161133517.png](https://img.hacpai.com/file/2019/10/image20191025161133517-21df8311.png)

![image20191025161803491.png](https://img.hacpai.com/file/2019/10/image20191025161803491-027c479c.png)

![image20191025162237109.png](https://img.hacpai.com/file/2019/10/image20191025162237109-e57285e6.png)

按照同样的方法，添加zabbix插件 >> 点击select >> 添加配置http url为zabbix api文件地址，文件名为：api_jsonrpc.php，默认存放在zabbix代码目录下

![image20191025160509594.png](https://img.hacpai.com/file/2019/10/image20191025160509594-34f19cf2.png)

![image20191025172001178.png](https://img.hacpai.com/file/2019/10/image20191025172001178-41c7fc3f.png)

![image20191025172325556.png](https://img.hacpai.com/file/2019/10/image20191025172325556-05dff93c.png)

点击左侧边栏的工具箱小图标，即可看到刚刚添加的两个数据源

![image20191025173220657.png](https://img.hacpai.com/file/2019/10/image20191025173220657-38a80aa2.png)

1.5 添加仪表板

![image20191025173741877.png](https://img.hacpai.com/file/2019/10/image20191025173741877-ee3034eb.png)

![image20191025174251518.png](https://img.hacpai.com/file/2019/10/image20191025174251518-5ac6536b.png)


在query mode可选择 查询方式 >> group 选择主机组 >> host 选择主机 >> aplication 选择应用集 >> item 选择监控项

![image20191025175530118.png](https://img.hacpai.com/file/2019/10/image20191025175530118-ec40266f.png)

![image20191028104518595.png](https://img.hacpai.com/file/2019/10/image20191028104518595-e38211bf.png)

![image20191028105151645.png](https://img.hacpai.com/file/2019/10/image20191028105151645-886bcc52.png)

![image20191028105456349.png](https://img.hacpai.com/file/2019/10/image20191028105456349-5b3eba82.png)


保存设置后，即可在主页看到刚添加的仪表板，点击仪表板，查看展示的数据  


![image20191028110029110.png](https://img.hacpai.com/file/2019/10/image20191028110029110-92d1b267.png)

![image20191028110149042.png](https://img.hacpai.com/file/2019/10/image20191028110149042-36cc1fb0.png)

----以上为基本的搭建教程，仅供参考，谢谢！
参考文档：
[https://grafana.com/docs/](https://grafana.com/docs/)

