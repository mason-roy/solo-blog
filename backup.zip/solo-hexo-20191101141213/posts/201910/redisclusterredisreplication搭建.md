title: redis cluster + redis replication 搭建
date: '2019-10-22 14:53:00'
updated: '2019-10-22 14:53:00'
tags: [redis]
permalink: /articles/2019/10/22/1571727179954.html
---


# redis cluster + redis replication 搭建


#### 环境
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191022142244807.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2dxajU0MDgyMTYx,size_16,color_FFFFFF,t_70)



## 部署搭建
##### 192.168.255.250

```bash
[root@vt-manager 3010]# grep -vE "^#|^$" redis.conf
bind 192.168.255.250  ##一定要写本机ip并且建立集群的时候要用这个ip建立
port 3010
daemonize yes  #守护线程模式（后台启动）
pidfile /etc/redis-cluster/3010/redis_3010.pid  #pid文件
logfile "/etc/redis-cluster/3010/redis.log"   #日志文件
dir "/etc/redis-cluster/3010/data"   #文件/数据路径
appendonly yes  #开启持久化功能
cluster-enabled yes    #启动集群
cluster-config-file nodes-3010.conf   #节点信息，自动生成
cluster-node-timeout 5000   #超时时间，单位毫秒
## 在搭建集群之前就设置密码的话可能会导致无法添加节点，所以在后面集群搭建好之后再进行设置就好了
# masterauth "1234qwe!@#"  #主机密码
# requirepass "1234qwe!@#"  #访问密码
```

**255.250:3011、255.100:3010-3011、255.101:3010-3011 配置均相同，只是把bind跟port以及路径修改一下即可**

```bash
#写完配置文件之后，分别启动六个节点
redis-server   /etc/redis-cluster/3010/redis.conf
```

**向集群添加master节点（需要多出一个port，此处直接在255.250上开启一个6379端口以控制cluster的添加删除等）**
**将255.250、100、101的3010端口作为master添加到cluster里面**
**--cluster-replicas 表示有一个主有几个slave**

```bash
[root@vt-manager redis-cluster]# redis-cli --cluster  create 192.168.255.250:3010  192.168.255.100:3010  192.168.255.101:3010 --cluster-replicas 0
>>> Performing hash slots allocation on 3 nodes...
Master[0] -> Slots 0 - 5460
Master[1] -> Slots 5461 - 10922
Master[2] -> Slots 10923 - 16383
M: 75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5 192.168.255.250:3010
   slots:[0-5460] (5461 slots) master
M: 278944c80cd36651809de466e9e9dd3fc243cc8b 192.168.255.100:3010
   slots:[5461-10922] (5462 slots) master
M: 0b7abd55faf62a007468eccc9a0fa30354df5adf 192.168.255.101:3010
   slots:[10923-16383] (5461 slots) master
Can I set the above configuration? (type 'yes' to accept): yes
>>> Nodes configuration updated
>>> Assign a different config epoch to each node
>>> Sending CLUSTER MEET messages to join the cluster
Waiting for the cluster to join
.
>>> Performing Cluster Check (using node 192.168.255.250:3010)
M: 75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5 192.168.255.250:3010
   slots:[0-5460] (5461 slots) master
M: 278944c80cd36651809de466e9e9dd3fc243cc8b 192.168.255.100:3010
   slots:[5461-10922] (5462 slots) master
M: 0b7abd55faf62a007468eccc9a0fa30354df5adf 192.168.255.101:3010
   slots:[10923-16383] (5461 slots) master
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.

#检查cluster状态，可以看到只有三个master而没有slave，master都对应有自己的uuid，此集群信息会记录到 nodes-**.conf文件里面
[root@vt-manager redis-cluster]# redis-cli  --cluster check 192.168.255.250:3010
192.168.255.250:3010 (75b5a3a5...) -> 0 keys | 5461 slots | 0 slaves.
192.168.255.100:3010 (278944c8...) -> 0 keys | 5462 slots | 0 slaves.
192.168.255.101:3010 (0b7abd55...) -> 0 keys | 5461 slots | 0 slaves.
[OK] 0 keys in 3 masters.
0.00 keys per slot on average.
>>> Performing Cluster Check (using node 192.168.255.250:3010)
M: 75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5 192.168.255.250:3010
   slots:[0-5460] (5461 slots) master
M: 278944c80cd36651809de466e9e9dd3fc243cc8b 192.168.255.100:3010
   slots:[5461-10922] (5462 slots) master
M: 0b7abd55faf62a007468eccc9a0fa30354df5adf 192.168.255.101:3010
   slots:[10923-16383] (5461 slots) master
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.

[root@vt-manager redis-cluster]# redis-cli  --cluster check 192.168.255.100:3010
192.168.255.100:3010 (278944c8...) -> 0 keys | 5462 slots | 0 slaves.
192.168.255.101:3010 (0b7abd55...) -> 0 keys | 5461 slots | 0 slaves.
192.168.255.250:3010 (75b5a3a5...) -> 0 keys | 5461 slots | 0 slaves.
[OK] 0 keys in 3 masters.
0.00 keys per slot on average.
>>> Performing Cluster Check (using node 192.168.255.100:3010)
M: 278944c80cd36651809de466e9e9dd3fc243cc8b 192.168.255.100:3010
   slots:[5461-10922] (5462 slots) master
M: 0b7abd55faf62a007468eccc9a0fa30354df5adf 192.168.255.101:3010
   slots:[10923-16383] (5461 slots) master
M: 75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5 192.168.255.250:3010
   slots:[0-5460] (5461 slots) master
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.

[root@vt-manager redis-cluster]# redis-cli  --cluster check 192.168.255.101:3010
192.168.255.101:3010 (0b7abd55...) -> 0 keys | 5461 slots | 0 slaves.
192.168.255.100:3010 (278944c8...) -> 0 keys | 5462 slots | 0 slaves.
192.168.255.250:3010 (75b5a3a5...) -> 0 keys | 5461 slots | 0 slaves.
[OK] 0 keys in 3 masters.
0.00 keys per slot on average.
>>> Performing Cluster Check (using node 192.168.255.101:3010)
M: 0b7abd55faf62a007468eccc9a0fa30354df5adf 192.168.255.101:3010
   slots:[10923-16383] (5461 slots) master
M: 278944c80cd36651809de466e9e9dd3fc243cc8b 192.168.255.100:3010
   slots:[5461-10922] (5462 slots) master
M: 75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5 192.168.255.250:3010
   slots:[0-5460] (5461 slots) master
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.
```

### 添加集群slave节点


为cluster添加nodes，并且是针对每一个master添加slave节点(格式: redis-cli --cluster add-node  slave-nodes-ip:port  控制节点ip:端口（任意集群中的节点都可）  --cluster-slave  --cluster-master-id  master-uuid )

```bash
[root@vt-manager redis-cluster]# redis-cli  --cluster add-node 192.168.255.100:3011 192.168.255.250:3010 --cluster-slave --cluster-master-id  75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5
>>> Adding node 192.168.255.100:3011 to cluster 192.168.255.250:3010
>>> Performing Cluster Check (using node 192.168.255.250:3010)
M: 75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5 192.168.255.250:3010
   slots:[0-5460] (5461 slots) master
M: 278944c80cd36651809de466e9e9dd3fc243cc8b 192.168.255.100:3010
   slots:[5461-10922] (5462 slots) master
M: 0b7abd55faf62a007468eccc9a0fa30354df5adf 192.168.255.101:3010
   slots:[10923-16383] (5461 slots) master
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.
>>> Send CLUSTER MEET to node 192.168.255.100:3011 to make it join the cluster.
Waiting for the cluster to join
>>> Configure node as replica of 192.168.255.250:3010.
[OK] New node added correctly.

[root@vt-manager redis-cluster]# redis-cli  --cluster add-node 192.168.255.101:3011 192.168.255.250:3010 --cluster-slave --cluster-master-id  278944c80cd36651809de466e9e9dd3fc243cc8b
>>> Adding node 192.168.255.101:3011 to cluster 192.168.255.250:3010
>>> Performing Cluster Check (using node 192.168.255.250:3010)
M: 75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5 192.168.255.250:3010
   slots:[0-5460] (5461 slots) master
   1 additional replica(s)
S: 5c4ac88c46b805ae6e51ac23ec5b2eb89c43d982 192.168.255.100:3011
   slots: (0 slots) slave
   replicates 75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5
M: 278944c80cd36651809de466e9e9dd3fc243cc8b 192.168.255.100:3010
   slots:[5461-10922] (5462 slots) master
M: 0b7abd55faf62a007468eccc9a0fa30354df5adf 192.168.255.101:3010
   slots:[10923-16383] (5461 slots) master
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.
>>> Send CLUSTER MEET to node 192.168.255.101:3011 to make it join the cluster.
Waiting for the cluster to join
>>> Configure node as replica of 192.168.255.100:3010.
[OK] New node added correctly.

[root@vt-manager redis-cluster]# redis-cli  --cluster add-node 192.168.255.250:3011 192.168.255.250:3010 --cluster-slave --cluster-master-id 0b7abd55faf62a007468eccc9a0fa30354df5adf
>>> Adding node 192.168.255.250:3011 to cluster 192.168.255.250:3010
>>> Performing Cluster Check (using node 192.168.255.250:3010)
M: 75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5 192.168.255.250:3010
   slots:[0-5460] (5461 slots) master
   1 additional replica(s)
S: adf58df6918571490eb51a0ea3a52df6812419fc 192.168.255.101:3011
   slots: (0 slots) slave
   replicates 278944c80cd36651809de466e9e9dd3fc243cc8b
M: 0b7abd55faf62a007468eccc9a0fa30354df5adf 192.168.255.101:3010
   slots:[10923-16383] (5461 slots) master
M: 278944c80cd36651809de466e9e9dd3fc243cc8b 192.168.255.100:3010
   slots:[5461-10922] (5462 slots) master
   1 additional replica(s)
S: 5c4ac88c46b805ae6e51ac23ec5b2eb89c43d982 192.168.255.100:3011
   slots: (0 slots) slave
   replicates 75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.
>>> Send CLUSTER MEET to node 192.168.255.250:3011 to make it join the cluster.
Waiting for the cluster to join
>>> Configure node as replica of 192.168.255.101:3010.
[OK] New node added correctly.

[root@vt-manager redis-cluster]# redis-cli  --cluster check 192.168.255.250:3010
192.168.255.250:3010 (75b5a3a5...) -> 0 keys | 5461 slots | 1 slaves.
192.168.255.101:3010 (0b7abd55...) -> 0 keys | 5461 slots | 1 slaves.
192.168.255.100:3010 (278944c8...) -> 0 keys | 5462 slots | 1 slaves.
[OK] 0 keys in 3 masters.
0.00 keys per slot on average.
>>> Performing Cluster Check (using node 192.168.255.250:3010)
M: 75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5 192.168.255.250:3010
   slots:[0-5460] (5461 slots) master
   1 additional replica(s)
S: 143ccae6e432af1c530e2a7d6fbfc2320e735316 192.168.255.250:3011
   slots: (0 slots) slave
   replicates 0b7abd55faf62a007468eccc9a0fa30354df5adf
S: adf58df6918571490eb51a0ea3a52df6812419fc 192.168.255.101:3011
   slots: (0 slots) slave
   replicates 278944c80cd36651809de466e9e9dd3fc243cc8b
M: 0b7abd55faf62a007468eccc9a0fa30354df5adf 192.168.255.101:3010
   slots:[10923-16383] (5461 slots) master
   1 additional replica(s)
M: 278944c80cd36651809de466e9e9dd3fc243cc8b 192.168.255.100:3010
   slots:[5461-10922] (5462 slots) master
   1 additional replica(s)
S: 5c4ac88c46b805ae6e51ac23ec5b2eb89c43d982 192.168.255.100:3011
   slots: (0 slots) slave
   replicates 75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.
```


### 查看节点状态

```bash
192.168.255.250:3010> cluster nodes
143ccae6e432af1c530e2a7d6fbfc2320e735316 192.168.255.250:3011@13011 slave 0b7abd55faf62a007468eccc9a0fa30354df5adf 0 1564373272729 3 connected
75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5 192.168.255.250:3010@13010 myself,master - 0 1564373268000 1 connected 0-5460
adf58df6918571490eb51a0ea3a52df6812419fc 192.168.255.101:3011@13011 slave 278944c80cd36651809de466e9e9dd3fc243cc8b 0 1564373273234 2 connected
0b7abd55faf62a007468eccc9a0fa30354df5adf 192.168.255.101:3010@13010 master - 0 1564373272228 3 connected 10923-16383
278944c80cd36651809de466e9e9dd3fc243cc8b 192.168.255.100:3010@13010 master - 0 1564373272000 2 connected 5461-10922
5c4ac88c46b805ae6e51ac23ec5b2eb89c43d982 192.168.255.100:3011@13011 slave 75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5 0 1564373271718 1 connected
192.168.255.250:3010> cluster info
cluster_state:ok
cluster_slots_assigned:16384
cluster_slots_ok:16384
cluster_slots_pfail:0
cluster_slots_fail:0
cluster_known_nodes:6
cluster_size:3
cluster_current_epoch:5
cluster_my_epoch:4
cluster_stats_messages_ping_sent:15951
cluster_stats_messages_pong_sent:14146
cluster_stats_messages_sent:30097
cluster_stats_messages_ping_received:14146
cluster_stats_messages_pong_received:14929
cluster_stats_messages_fail_received:2
cluster_stats_messages_auth-req_received:1
cluster_stats_messages_received:29078
```


### 设置集群nodes密码（每个node都需要进行设置）


```bash
192.168.255.250:3010> config set masterauth 1234qwe!@#
OK
192.168.255.250:3010> config set requirepass 1234qwe!@#
OK
192.168.255.250:3010> auth 1234qwe!@#
OK
192.168.255.250:3010> config rewrite
OK
```


### 扩容集群节点


```bash
[root@vt-manager app]# redis-cli --cluster add-node 192.168.255.253:3010  192.168.255.250:3010  -a 1234qwe!@#   #这里是将节点加入了集群中，但是并没有分配slot，所以这个节点并没有真正的开始分担集群工作。
Warning: Using a password with '-a' or '-u' option on the command line interface may not be safe.
>>> Adding node 192.168.255.253:3010 to cluster 192.168.255.250:3010
>>> Performing Cluster Check (using node 192.168.255.250:3010)
S: 75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5 192.168.255.250:3010
   slots: (0 slots) slave
   replicates 5c4ac88c46b805ae6e51ac23ec5b2eb89c43d982
S: 278944c80cd36651809de466e9e9dd3fc243cc8b 192.168.255.100:3010
   slots: (0 slots) slave
   replicates adf58df6918571490eb51a0ea3a52df6812419fc
M: adf58df6918571490eb51a0ea3a52df6812419fc 192.168.255.101:3011
   slots:[5461-10922] (5462 slots) master
   1 additional replica(s)
M: 0b7abd55faf62a007468eccc9a0fa30354df5adf 192.168.255.101:3010
   slots:[10923-16383] (5461 slots) master
   1 additional replica(s)
M: 5c4ac88c46b805ae6e51ac23ec5b2eb89c43d982 192.168.255.100:3011
   slots:[0-5460] (5461 slots) master
   1 additional replica(s)
S: 143ccae6e432af1c530e2a7d6fbfc2320e735316 192.168.255.250:3011
   slots: (0 slots) slave
   replicates 0b7abd55faf62a007468eccc9a0fa30354df5adf
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.
>>> Send CLUSTER MEET to node 192.168.255.253:3010 to make it join the cluster.
[OK] New node added correctly.

[root@vt-manager app]# redis-cli  --cluster check 192.168.255.250:3010 -a 1234qwe!@#
Warning: Using a password with '-a' or '-u' option on the command line interface may not be safe.
192.168.255.101:3011 (adf58df6...) -> 4 keys | 5462 slots | 1 slaves.
192.168.255.253:3010 (d700cfa9...) -> 0 keys | 0 slots | 0 slaves.
192.168.255.101:3010 (0b7abd55...) -> 4 keys | 5461 slots | 1 slaves.
192.168.255.100:3011 (5c4ac88c...) -> 4 keys | 5461 slots | 1 slaves.
[OK] 12 keys in 4 masters.
0.00 keys per slot on average.
>>> Performing Cluster Check (using node 192.168.255.250:3010)
S: 75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5 192.168.255.250:3010
   slots: (0 slots) slave
   replicates 5c4ac88c46b805ae6e51ac23ec5b2eb89c43d982
S: 278944c80cd36651809de466e9e9dd3fc243cc8b 192.168.255.100:3010
   slots: (0 slots) slave
   replicates adf58df6918571490eb51a0ea3a52df6812419fc
M: adf58df6918571490eb51a0ea3a52df6812419fc 192.168.255.101:3011
   slots:[5461-10922] (5462 slots) master
   1 additional replica(s)
M: d700cfa9b25a44cee8805783cf9548ce525b337a 192.168.255.253:3010
   slots: (0 slots) master
M: 0b7abd55faf62a007468eccc9a0fa30354df5adf 192.168.255.101:3010
   slots:[10923-16383] (5461 slots) master
   1 additional replica(s)
M: 5c4ac88c46b805ae6e51ac23ec5b2eb89c43d982 192.168.255.100:3011
   slots:[0-5460] (5461 slots) master
   1 additional replica(s)
S: 143ccae6e432af1c530e2a7d6fbfc2320e735316 192.168.255.250:3011
   slots: (0 slots) slave
   replicates 0b7abd55faf62a007468eccc9a0fa30354df5adf
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.
```


### 分配slot,让新加入cluster的节点提集群分担工作


--cluster-from：表示slot目前所在的节点的node ID，多个ID用逗号分隔
--cluster-to：表示需要新分配节点的node ID（貌似每次只能分配一个）
--cluster-slots：分配的slot数量

```bash
[root@vt-manager app]# redis-cli --cluster reshard 192.168.255.253:3010 --cluster-from  5c4ac88c46b805ae6e51ac23ec5b2eb89c43d982,adf58df6918571490eb51a0ea3a52df6812419fc,0b7abd55faf62a007468eccc9a0fa30354df5adf --cluster-to d700cfa9b25a44cee8805783cf9548ce525b337a --cluster-slots 5461 -a 1234qwe!@#
[root@vt-manager app]# redis-cli  --cluster check 192.168.255.250:3010 -a 1234qwe!@#
Warning: Using a password with '-a' or '-u' option on the command line interface may not be safe.
192.168.255.101:3011 (adf58df6...) -> 3 keys | 3641 slots | 1 slaves.
192.168.255.253:3010 (d700cfa9...) -> 3 keys | 5461 slots | 0 slaves.
192.168.255.101:3010 (0b7abd55...) -> 4 keys | 3641 slots | 1 slaves.
192.168.255.100:3011 (5c4ac88c...) -> 2 keys | 3641 slots | 1 slaves.
[OK] 12 keys in 4 masters.
0.00 keys per slot on average.
>>> Performing Cluster Check (using node 192.168.255.250:3010)
S: 75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5 192.168.255.250:3010
   slots: (0 slots) slave
   replicates 5c4ac88c46b805ae6e51ac23ec5b2eb89c43d982
S: 278944c80cd36651809de466e9e9dd3fc243cc8b 192.168.255.100:3010
   slots: (0 slots) slave
   replicates adf58df6918571490eb51a0ea3a52df6812419fc
M: adf58df6918571490eb51a0ea3a52df6812419fc 192.168.255.101:3011
   slots:[7282-10922] (3641 slots) master
   1 additional replica(s)
M: d700cfa9b25a44cee8805783cf9548ce525b337a 192.168.255.253:3010
   slots:[0-1819],[5461-7281],[10923-12742] (5461 slots) master
M: 0b7abd55faf62a007468eccc9a0fa30354df5adf 192.168.255.101:3010
   slots:[12743-16383] (3641 slots) master
   1 additional replica(s)
M: 5c4ac88c46b805ae6e51ac23ec5b2eb89c43d982 192.168.255.100:3011
   slots:[1820-5460] (3641 slots) master
   1 additional replica(s)
S: 143ccae6e432af1c530e2a7d6fbfc2320e735316 192.168.255.250:3011
   slots: (0 slots) slave
   replicates 0b7abd55faf62a007468eccc9a0fa30354df5adf
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.
```

### 为255.253:3010添加slave node 

（因为目前有4个master 跟3个slave ，所以架构图需要进行调整，将原来的255.101:3010 -> 255.250:3011调整为255.101:3010 -> 255.253:3011    原来的255.250的3011作为 255.253的slave 255.253:3010 -> 255.250:3011）
add-node: 后面的分别跟着新加入的slave和slave对应的master
cluster-slave：表示加入的是slave节点
--cluster-master-id：表示slave对应的master的node ID

```bash
[root@vt-manager app]# redis-cli  --cluster check 192.168.255.250:3010 -a 1234qwe!@#
Warning: Using a password with '-a' or '-u' option on the command line interface may not be safe.
192.168.255.101:3011 (adf58df6...) -> 3 keys | 3641 slots | 1 slaves.
192.168.255.253:3010 (d700cfa9...) -> 3 keys | 5461 slots | 0 slaves.
192.168.255.101:3010 (0b7abd55...) -> 4 keys | 3641 slots | 1 slaves.
192.168.255.100:3011 (5c4ac88c...) -> 2 keys | 3641 slots | 1 slaves.
[OK] 12 keys in 4 masters.
0.00 keys per slot on average.
>>> Performing Cluster Check (using node 192.168.255.250:3010)
S: 75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5 192.168.255.250:3010
   slots: (0 slots) slave
   replicates 5c4ac88c46b805ae6e51ac23ec5b2eb89c43d982
S: 278944c80cd36651809de466e9e9dd3fc243cc8b 192.168.255.100:3010
   slots: (0 slots) slave
   replicates adf58df6918571490eb51a0ea3a52df6812419fc
M: adf58df6918571490eb51a0ea3a52df6812419fc 192.168.255.101:3011
   slots:[7282-10922] (3641 slots) master
   1 additional replica(s)
M: d700cfa9b25a44cee8805783cf9548ce525b337a 192.168.255.253:3010
   slots:[0-1819],[5461-7281],[10923-12742] (5461 slots) master
M: 0b7abd55faf62a007468eccc9a0fa30354df5adf 192.168.255.101:3010
   slots:[12743-16383] (3641 slots) master
   1 additional replica(s)
M: 5c4ac88c46b805ae6e51ac23ec5b2eb89c43d982 192.168.255.100:3011
   slots:[1820-5460] (3641 slots) master
   1 additional replica(s)
S: 143ccae6e432af1c530e2a7d6fbfc2320e735316 192.168.255.250:3011
   slots: (0 slots) slave
   replicates 0b7abd55faf62a007468eccc9a0fa30354df5adf
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.

[root@vt-manager app]# redis-cli --cluster del-node 192.168.255.250:3011 143ccae6e432af1c530e2a7d6fbfc2320e735316 -a 1234qwe!@#
Warning: Using a password with '-a' or '-u' option on the command line interface may not be safe.
>>> Removing node 143ccae6e432af1c530e2a7d6fbfc2320e735316 from cluster 192.168.255.250:3011
>>> Sending CLUSTER FORGET messages to the cluster...
>>> SHUTDOWN the node.

[root@vt-manager app]# redis-cli --cluster add-node 192.168.255.253:3011  192.168.255.250:3010 --cluster-slave --cluster-master-id  0b7abd55faf62a007468eccc9a0fa30354df5adf  -a 1234qwe!@#
Warning: Using a password with '-a' or '-u' option on the command line interface may not be safe.
>>> Adding node 192.168.255.253:3011 to cluster 192.168.255.250:3010
>>> Performing Cluster Check (using node 192.168.255.250:3010)
S: 75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5 192.168.255.250:3010
   slots: (0 slots) slave
   replicates 5c4ac88c46b805ae6e51ac23ec5b2eb89c43d982
S: 278944c80cd36651809de466e9e9dd3fc243cc8b 192.168.255.100:3010
   slots: (0 slots) slave
   replicates adf58df6918571490eb51a0ea3a52df6812419fc
M: adf58df6918571490eb51a0ea3a52df6812419fc 192.168.255.101:3011
   slots:[7282-10922] (3641 slots) master
   1 additional replica(s)
M: d700cfa9b25a44cee8805783cf9548ce525b337a 192.168.255.253:3010
   slots:[0-1819],[5461-7281],[10923-12742] (5461 slots) master
M: 0b7abd55faf62a007468eccc9a0fa30354df5adf 192.168.255.101:3010
   slots:[12743-16383] (3641 slots) master
M: 5c4ac88c46b805ae6e51ac23ec5b2eb89c43d982 192.168.255.100:3011
   slots:[1820-5460] (3641 slots) master
   1 additional replica(s)
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.
>>> Send CLUSTER MEET to node 192.168.255.253:3011 to make it join the cluster.
Waiting for the cluster to join
>>> Configure node as replica of 192.168.255.101:3010.
[OK] New node added correctly.

因为255.250:3011 原来是做从用的，里面会有集群节点信息跟数据，所以需要删除掉原来的数据才可正常；
=======================================================================================
[root@vt-manager app]# rm -rf  /etc/redis-cluster/3011/data/*
[root@vt-manager app]# redis-server   /etc/redis-cluster/3011/redis.conf
[root@vt-manager app]# redis-cli --cluster add-node 192.168.255.250:3011  192.168.255.250:3010 --cluster-slave --cluster-master-id  d700cfa9b25a44cee8805783cf9548ce525b337a  -a 1234qwe!@#
Warning: Using a password with '-a' or '-u' option on the command line interface may not be safe.
>>> Adding node 192.168.255.250:3011 to cluster 192.168.255.250:3010
>>> Performing Cluster Check (using node 192.168.255.250:3010)
S: 75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5 192.168.255.250:3010
   slots: (0 slots) slave
   replicates 5c4ac88c46b805ae6e51ac23ec5b2eb89c43d982
S: 278944c80cd36651809de466e9e9dd3fc243cc8b 192.168.255.100:3010
   slots: (0 slots) slave
   replicates adf58df6918571490eb51a0ea3a52df6812419fc
M: adf58df6918571490eb51a0ea3a52df6812419fc 192.168.255.101:3011
   slots:[7282-10922] (3641 slots) master
   1 additional replica(s)
M: d700cfa9b25a44cee8805783cf9548ce525b337a 192.168.255.253:3010
   slots:[0-1819],[5461-7281],[10923-12742] (5461 slots) master
M: 0b7abd55faf62a007468eccc9a0fa30354df5adf 192.168.255.101:3010
   slots:[12743-16383] (3641 slots) master
   1 additional replica(s)
M: 5c4ac88c46b805ae6e51ac23ec5b2eb89c43d982 192.168.255.100:3011
   slots:[1820-5460] (3641 slots) master
   1 additional replica(s)
S: 8f33ed15a736bb86c11f16294b68241d848073ca 192.168.255.253:3011
   slots: (0 slots) slave
   replicates 0b7abd55faf62a007468eccc9a0fa30354df5adf
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.
>>> Send CLUSTER MEET to node 192.168.255.250:3011 to make it join the cluster.
Waiting for the cluster to join
>>> Configure node as replica of 192.168.255.253:3010.
[OK] New node added correctly.
========================================================================

[root@vt-manager app]# redis-cli  --cluster check 192.168.255.250:3010 -a 1234qwe!@#
Warning: Using a password with '-a' or '-u' option on the command line interface may not be safe.
192.168.255.101:3011 (adf58df6...) -> 3 keys | 3641 slots | 1 slaves.
192.168.255.253:3010 (d700cfa9...) -> 3 keys | 5461 slots | 1 slaves.
192.168.255.101:3010 (0b7abd55...) -> 4 keys | 3641 slots | 1 slaves.
192.168.255.100:3011 (5c4ac88c...) -> 2 keys | 3641 slots | 1 slaves.
[OK] 12 keys in 4 masters.
0.00 keys per slot on average.
>>> Performing Cluster Check (using node 192.168.255.250:3010)
S: 75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5 192.168.255.250:3010
   slots: (0 slots) slave
   replicates 5c4ac88c46b805ae6e51ac23ec5b2eb89c43d982
S: 278944c80cd36651809de466e9e9dd3fc243cc8b 192.168.255.100:3010
   slots: (0 slots) slave
   replicates adf58df6918571490eb51a0ea3a52df6812419fc
M: adf58df6918571490eb51a0ea3a52df6812419fc 192.168.255.101:3011
   slots:[7282-10922] (3641 slots) master
   1 additional replica(s)
S: d3c105351fffd4419bc5101819699af984f3a83b 192.168.255.250:3011
   slots: (0 slots) slave
   replicates d700cfa9b25a44cee8805783cf9548ce525b337a
M: d700cfa9b25a44cee8805783cf9548ce525b337a 192.168.255.253:3010
   slots:[0-1819],[5461-7281],[10923-12742] (5461 slots) master
   1 additional replica(s)
M: 0b7abd55faf62a007468eccc9a0fa30354df5adf 192.168.255.101:3010
   slots:[12743-16383] (3641 slots) master
   1 additional replica(s)
M: 5c4ac88c46b805ae6e51ac23ec5b2eb89c43d982 192.168.255.100:3011
   slots:[1820-5460] (3641 slots) master
   1 additional replica(s)
S: 8f33ed15a736bb86c11f16294b68241d848073ca 192.168.255.253:3011
   slots: (0 slots) slave
   replicates 0b7abd55faf62a007468eccc9a0fa30354df5adf
[OK] All nodes agree about slots configuration.
>>> Check for open slots...
>>> Check slots coverage...
[OK] All 16384 slots covered.

[root@vt-manager app]# redis-cli  -c -h 192.168.255.250 -p 3010   -a 1234qwe!@#   cluster nodes
Warning: Using a password with '-a' or '-u' option on the command line interface may not be safe.
278944c80cd36651809de466e9e9dd3fc243cc8b 192.168.255.100:3010@13010 slave adf58df6918571490eb51a0ea3a52df6812419fc 0 1564386981109 5 connected
adf58df6918571490eb51a0ea3a52df6812419fc 192.168.255.101:3011@13011 master - 0 1564386982116 5 connected 7282-10922
d3c105351fffd4419bc5101819699af984f3a83b 192.168.255.250:3011@13011 slave d700cfa9b25a44cee8805783cf9548ce525b337a 0 1564386980100 6 connected
d700cfa9b25a44cee8805783cf9548ce525b337a 192.168.255.253:3010@13010 master - 0 1564386980101 6 connected 0-1819 5461-7281 10923-12742
0b7abd55faf62a007468eccc9a0fa30354df5adf 192.168.255.101:3010@13010 master - 0 1564386981611 3 connected 12743-16383
75b5a3a58ad4c8c668ad2905cec76612f1eeb4e5 192.168.255.250:3010@13010 myself,slave 5c4ac88c46b805ae6e51ac23ec5b2eb89c43d982 0 1564386977000 1 connected
5c4ac88c46b805ae6e51ac23ec5b2eb89c43d982 192.168.255.100:3011@13011 master - 0 1564386981611 4 connected 1820-5460
8f33ed15a736bb86c11f16294b68241d848073ca 192.168.255.253:3011@13011 slave 0b7abd55faf62a007468eccc9a0fa30354df5adf 0 1564386980101 3 connected
```

### Redis常见配置
**收缩集群**


```bash
下线节点127.0.0.1:6385（master）/127.0.0.1:6386（slave）
（1）首先删除master对应的slave
redis-cli --cluster del-node 127.0.0.1:6386 530cf27337c1141ed12268f55ba06c15ca8494fc
del-node后面跟着slave节点的 ip:port 和node ID
（2）清空master的slot
redis-cli --cluster reshard 127.0.0.1:6385 --cluster-from 46f0b68b3f605b3369d3843a89a2b4a164ed21e8 --cluster-to 2846540d8284538096f111a8ce7cf01c50199237 --cluster-slots 1024 --cluster-yes
reshard子命令前面已经介绍过了，这里需要注意的一点是，由于我们的集群一共有四个主节点，而每次reshard只能写一个目的节点，因此以上命令需要执行三次（--cluster-to对应不同的目的节点）。
--cluster-yes：不会显示需要迁移的slot，直接迁移。
（3）下线（删除）节点
redis-cli --cluster del-node 127.0.0.1:6385 46f0b68b3f605b3369d3843a89a2b4a164ed21e8
```

### redis加入systemctl开机启动。


#### （1）、首先需要把redis.conf中的

```bash
daemonize yes
修改为
daemonize no
```

#### (2)、创建启动脚本

```bash
vim /lib/systemd/system/redis.service
在redis.service中输入以下内容
[Unit]
Description=The redis-server Process Manager
After=syslog.target network.target
[Service]
#Type=forking
PIDFile=/var/run/redis.pid
ExecStart=/usr/local/redis/bin/redis-server /usr/local/redis/etc/redis.conf  #指定运行程序以及redis配置文件
ExecReload=/bin/kill -USR2 $MAINPID
ExecStop=/bin/kill -SIGINT $MAINPID
[Install]
WantedBy=multi-user.target
#重新载入 systemd
systemctl daemon-reload
#启动redis
systemctl start redis
#加入开机启动
systemctl enable redis
#查看redis状态
systemctl status redis
#停止redis
systemctl stop redis
```


#### 如果节点添加错误之后的删除方法


```bash
redis-cli  --cluster del-node  slave-node:port  slave-uuid
redis-cli --cluster del-node 192.168.255.100:3011  011367d777d2ef363f8a15689efa9df4b0bed8b8
除了在此处删除，还需要删除nodes-xx.conf里面的值，最直接的方法是将这个文件删除，以为重启节点后会生成一个新的文件
如果不删除会导致 100:3011无法重新添加进来（因为键值冲突）
```


