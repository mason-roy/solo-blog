title: jenkins 安装及配置部署操作 （jenkins+svn+tomcat  and  jenkins+git+maven+tomcat）
date: '2019-10-04 10:34:44'
updated: '2019-10-04 14:04:30'
tags: [Jenkins, 代码发布, maven]
permalink: /articles/2019/10/04/1570156484758.html
---
![](https://img.hacpai.com/bing/20190413.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


**jenkins rpm软件包下载地址：   https://pkg.jenkins.io/redhat/
jenkins  软件包下载地址：         https://jenkins.io/download/
jenkins  插件下载地址：            http://ftp.icm.edu.pl/packages/jenkins/plugins/**

**文档相关软件下载链接
链接：https://pan.baidu.com/s/1_zs_rjghH1d6Y4VN1KgYIA
提取码：06lb**


>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
>>##  jenkins 安装配置 >>>>
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

因为这的jenkins的配置都一样，所以只写一次
**1、安装jdk ，配置好环境变量JAVA_HOME，后面会有用到 。**

```
[root@jenkins ~]# tar zxf jdk1.8.0_191.tar.gz
[root@jenkins ~]# mv jdk1.8.0_191   /usr/local/jdk1.8.0
[root@jenkins ~]# echo "export JAVA_HOME=/usr/local/jdk1.8.0" >> /etc/profile
[root@jenkins ~]# echo "export PATH=$JAVA_HOME/bin:$PATH" >> /etc/profile
[root@jenkins ~]# source  /etc/profile
[root@jenkins ~]# echo $JAVA_HOME
/usr/local/jdk1.8.0
```


** 2、安装jenkins 软件，可以使用rpm也可以使用war包去运行 。  jenkins安装依赖openjdk软件。**

```
[root@jenkins ~]# yum localinstall  jenkins-2.195-1.1.noarch.rpm  -y
[root@jenkins ~]# yum install java-1.8.0-openjdk -y
[root@jenkins ~]# systemctl  start jenkins
[root@jenkins ~]# systemctl  enable jenkins
[root@jenkins ~]# /sbin/chkconfig  jenkins on
```


**3、打开浏览器 http://ip:port  登陆jenkins ，密码在下面文件内 。**

```
[root@jenkins ~]# cat /var/lib/jenkins/secrets/initialAdminPassword
f50bc74962b6449aab7f72cee8ab898f
```
![1.png](https://img.hacpai.com/file/2019/10/1-86a5ad35.png)



**4、网上很多人喜欢“安装推荐的插件”，其实这种方式对于网络不好或者是不能访问外网的人来说是不行的，会报错。网络差的会很慢很慢，所以我选 “选择插件来安装”，把所有插件取消掉。**

![2.png](https://img.hacpai.com/file/2019/10/2-af1120cc.png)


**5、取消所有插件，一个都不安装**

![3.png](https://img.hacpai.com/file/2019/10/3-a10f5915.png)



**6、配置管理员用户，一定要配置，不然你后面进去就非常麻烦的**。 

![4.png](https://img.hacpai.com/file/2019/10/4-178242c0.png)



**7、输入jenkins实例url ，一般使用默认即可 。**

![5.png](https://img.hacpai.com/file/2019/10/5-07b2140e.png)



**8、安装完毕，开始使用jenkins**

![6.png](https://img.hacpai.com/file/2019/10/6-4bfe0cd4.png)



**9、登陆后的界面 。**

![7.png](https://img.hacpai.com/file/2019/10/7-69789f5a.png)




**10、选择管理jenkins ，插件管理。**

![8.png](https://img.hacpai.com/file/2019/10/8-90d1715f.png)




**11、发现已安装插件内，没有任何插件 。**

![9.png](https://img.hacpai.com/file/2019/10/9-55d7be81.png)



==============================
**安装插件的三种方式：
插件安装一：**
      找一台已经安装好插件的机器，把/var/lib/jenkins/plugins目录里面的文件跟目录全部拷贝出来。将插件对应的文件导入到   /var/lib/jenkins/plugins 目录下面，然后修改权限  chown  -R  jenkins:jenkins  *
重启  systemctl restart jenkins

**插件安装二：**
      到 http://ftp.icm.edu.pl/packages/jenkins/plugins/ 下载对应的插件，选择插件管理里面的高级，上传插件-->选择文件-->上传 （jenkins 2.175用的是 hpi文件），上传完之后就会自动开始安装。这种方法比较慢，需要一个文件一个文件的选择。

**插件安装三：**
      到可选插件内勾选自己想要的插件，点击安装即可 。


**以下是以完成插件安装的截图 ：**

![10.png](https://img.hacpai.com/file/2019/10/10-8a9d9e82.png)







**12、配置后面要用到管理的参数，publish over ssh key ，管理jenkins -->系统设置 ，找到这里将jenkins的key放入这里，下面配置后期需要推送文件的服务器ip，远程账号以及远程上去的目录位置。 （jenkins与需要推送文件的服务器之间需要免密登陆，远程账号不一定用root,也可以用其他普通用户）**
![11.png](https://img.hacpai.com/file/2019/10/11-05bd20e6.png)


jenkins的安装配置到此结束；



## 一、jenkins+svn+tomcat

**项目说明：**
1、svn服务器用于存放页面代码以及更新版本库 ，所有的页面从svn上面进行控制 ；
2、tomcat用来部署页面，所有的访问都通过tomcat 进行 ；
3、jenkins 用来做更新版本控制，需要带有回滚版本的功能 ；

**搭建思路：**
1、开发人员统一将文件上传到svn对应的目录下面。例如  svn://xxx/work1/dist.zip     svn://xxx/work2/dist.zip 
2、jenkins收集到所有的dist.zip之后 先打包一个压缩文件到workspace/dist/xxx-x.tar.gz ，用于后面还原用
3、jenkins推送.tar.gz文件到tomcat 对应的目录下并解压，解压之前先清空里面的文件 。
192.168.255.130  jenkins - 2.195
192.168.255.100  svn -  1.7.14
192.168.255.101  tomcat - 8

![12.png](https://img.hacpai.com/file/2019/10/12-b77724a8.png)



>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
>> svn 搭建及配置  >>>>
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


**1、安装svn **

```
[root@svn ~]# yum install subversion -y
```


**2、创建svn库对应的目录**

```
[root@svn ~]# mkdir  -p /server/svn
[root@svn ~]# svnadmin  create /server/svn
[root@svn ~]# ls /server/svn/
conf  db  format  hooks  locks  README.txt
```


**3、对svn版本库进行配置**

```
[root@svn ~]# cd /server/svn/conf/
[root@svn conf]# ls
authz  passwd  svnserve.conf
```


**4、添加登陆用户名跟密码，均为appuser**

```
[root@svn conf]# tail -2 passwd
    [users]
    appuser = appuser
```


**5、设置用户访问权限，appuser可以对svn的 / 有读写权限，其他用户没有权限**

```
[root@svn conf]# tail -3 authz
    [/]
    appuser = rw
    * =
```


**6、配置svn密码库文件、权限库文件以及svn根的对应目录**

```
[root@svn conf]# vim svnserve.conf
    anon-access = read
    auth-access = write
    password-db = passwd
    authz-db = authz
    realm = /server/svn
```


**7、启动svn服务**

```
[root@svn conf]# svnserve   -d -r  /server/svn/
[root@svn conf]# ps -ef| grep svnserve
root       2391      1  0 16:22 ?        00:00:00 svnserve -d -r /server/svn/
root       2393   2167  0 16:22 pts/0    00:00:00 grep --color=auto svnserve
```


**8、创建svn客户端目录并检出库内容**

```
[root@svn conf]# mkdir -p /data/tomcat
[root@svn conf]# svn checkout  svn://192.168.255.100/   /data/tomcat
[root@svn conf]# cd /data/tomcat/
```


**9、添加文件**
```
[root@svn tomcat]# echo "test 16:40" > 1.txt
```


**10、将文件添加到svn库**

```
[root@svn tomcat]# svn add  1.txt  
A         1.txt
```


**11、提交版本更新并备注提交信息**

```
[root@svn tomcat]# svn commit  -m 'test create 1.txt' ./
Adding         1.txt
Transmitting file data .
Committed revision 1.
```


**12、查看svn状态**
```
[root@svn tomcat]# svn status -v
                 0        0  ?           .
                 1        1 appuser      1.txt
```




>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
>> tomcat 搭建及配置  >>>>
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


**安装openjdk跟tomcat 并启动 ，使用默认配置即可**

```
[root@tomcat ~]#  yum install java-1.8.0-openjdk  -y
[root@tomcat ~]#  tar zxvf apache-tomcat-8.0.30.tar.gz  
[root@tomcat ~]#  mv apache-tomcat-8.0.30 /usr/local/tomcat

[root@tomcat ~]#  cd /usr/local/tomcat/
[root@tomcat tomcat]# bin/startup.sh
```


**确认服务是否起来**

```
[root@tomcat tomcat]# netstat  -anputl| grep LISTEN
tcp        0      0 0.0.0.0:22              0.0.0.0:*               LISTEN      923/sshd            
tcp        0      0 127.0.0.1:25            0.0.0.0:*               LISTEN      1169/master         
tcp6       0      0 :::8080                 :::*                    LISTEN      2345/java           
tcp6       0      0 :::22                   :::*                    LISTEN      923/sshd            
tcp6       0      0 ::1:25                  :::*                    LISTEN      1169/master         
tcp6       0      0 127.0.0.1:8005          :::*                    LISTEN      2345/java           
tcp6       0      0 :::8009                 :::*                    LISTEN      2345/java          
``` 




>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
>> jenkins 项目部署配置  >>>>
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


**1、创建项目 -->>  构建一个自由风格的软件项目 ；**

![13.png](https://img.hacpai.com/file/2019/10/13-1c3ab2fd.png)



**2、选择参数化构建过程 （这里的参数化将会在后面项目构建处进行体现）**

![14.png](https://img.hacpai.com/file/2019/10/14-25425204.png)


**
3、配置svn库地址跟svn账号密码**

![15.png](https://img.hacpai.com/file/2019/10/15-2e954440.png)




**4、选择用户名跟密码，配置 appuser （svn的账号密码）**

![16.png](https://img.hacpai.com/file/2019/10/16-ec7bef5b.png)



**5、选择刚才配置的账号密码作为凭证 （凭证也可以在jenkins设置里面进行添加）**

![17.png](https://img.hacpai.com/file/2019/10/17-f19179ca.png)



**6、添加构建步骤，选择执行shell 脚本**

![18.png](https://img.hacpai.com/file/2019/10/18-283865ae.png)



**脚本内容即为判断前面 参数化构建过程 内的参数，首先匹配名称，如果名称匹配成功就开始匹配下面的 Deploy 或者RollBACK ，执行对应的语句。   目前对于打包时会做一个判断，保留十个打包备份，能够很好的节约jenkins的空间。
这里只是做了打包备份，并没有做发布**

![19.png](https://img.hacpai.com/file/2019/10/19-13728904.png)



脚本的文字
```
case $Status in
    Deploy)
        echo "Status: $Status"
        path="${WORKSPACE}/dist"
        if [ -d $path ];then
            echo "The file is already exists!!!"
        else
            mkdir -p $path
        fi
        cd ${WORKSPACE}
        tar czf dist/${JOB_NAME}-${BUILD_NUMBER}.tar.gz * --exclude=dist
        echo "Completion!!!"
        cd  dist
        total_file_num=`ls -l | grep -v 'total' | wc -l`
            if [ $total_file_num -gt 10 ];
            then
                num=`expr $total_file_num - 10`
                files=`ls -ltr | grep -v 'total' | awk '{print $9}' | head -n $num`
                echo $files | xargs rm -f
                echo "保留10个备份，删除早期备份: " $files
            else
                echo "没有更多的版本"
            fi
        ;;
    RollBACK)
        echo "Status: $Status"
        echo "version: $Version"
        file_old=`ls ${WORKSPACE}/dist | grep $Version`
        cd ${WORKSPACE}/dist
        cp -R $file_old ${JOB_NAME}-${BUILD_NUMBER}.tar.gz
        ;;
    *)
    exit
        ;;
esac
```



**7、添加第二个构建步骤，此处先关闭tomcat，然后删除需要上传文件的目录里面的内容。  （也可以把脚本写到tomcat的服务器里面，写这里是为了能够让管理者更加直观的看到做了什么）
jenkins的构建步骤都是严格按照先后顺序来执行的，所以要做什么操作请按照顺序来 ；**

![20.png](https://img.hacpai.com/file/2019/10/20-a0f9f8ea.png)

![21.png](https://img.hacpai.com/file/2019/10/21-df2dd752.png)





**8、将之前打包的压缩包发送到tomcat上面并执行解压，解压完毕之后执行启动tomcat命令。 （这个可以放在构建步骤里面也可以放在构建后操作步骤里面，效果是一样的，只要顺序没错）**


![22.png](https://img.hacpai.com/file/2019/10/22-f6652a23.png)

![23.png](https://img.hacpai.com/file/2019/10/23-f49a5ee9.png)



**因为项目需求不同，所以这里做的都是全量版本更新，如果想要做svn的增量版本更新的话可以使用下面的操作方式**

内容来源 ： https://blog.csdn.net/q13554515812/article/details/86651851
进入【系统管理】-【Jenkins命令行接口】，进入【Jenkins命令行】页面，下载jenkins-cli.jar，放到Svn所在服务器的root目录下，如下图：
（发布项目的用户必须要有可执行权限，默认的项目执行用户家目录配置在  系统配置- -> publish over ssh key -> ssh servers -> Remote Directory ）
![24.png](https://img.hacpai.com/file/2019/10/24-91e6c5c3.png)

进入Svn的hooks目录下，创建文件post-commit，并赋予执行权限，如下图：
![25.png](https://img.hacpai.com/file/2019/10/25-4f95213f.png)

**编辑文件post-commit，内容如下：**
-auth 为添加认证 ，  test:123qwe 为账号跟密码，  build 为打包， test为项目名称。
```
#!/bin/bash
source /etc/profile
java -jar /root/jenkins-cli.jar -s http://47.104.77.127:8080/jenkins/ -auth test:123qwe build test    
```

**svn提交代码后，查看Jenkins任务是否触发。**
FAQ
**Q：svn 钩子 post-commit 出现255错误**
R：post-commit 脚本文件的权限不对
S：post-commit 脚本必须有 +x 权限，给post-commit添加可执行权限
参见：https://blog.csdn.net/webnoties/article/details/40539431        

**Q：svn提交代码，触发post-commit钩子，出现如下报错：**    
![26.png](https://img.hacpai.com/file/2019/10/26-869ad36a.png)

R：post-commit脚本中缺少JDK环境变量
S：post-commit脚本中添加source /etc/profile  

**Q：执行命令java -jar /root/jenkins-cli.jar -s http://47.104.77.127:8080/jenkins/ build test出现如下错误：'ERROR: anonymous is missing the Overall/Read permission'**
R：没有进行身份验证
S：
方案一：
进入Jenkins【系统管理】-【全局安全配置】-【授权策略】选中【登录用户可以做任何事】后保存
方案二：
命令中添加-auth参数，修改命令如下：
java -jar /root/jenkins-cli.jar -s http://47.104.77.127:8080/jenkins/ -auth test:123qwe build test               



## 二、jenkins+git+maven+tomcat



**项目说明：**
1、git服务器用于存放页面代码以及更新版本库 ，所有的页面从git上面进行控制 ；
2、tomcat用来部署页面，所有的访问都通过tomcat 进行 ；
3、jenkins 用来做更新版本控制，需要带有回滚版本的功能 ；
4、git服务器上面全部均为源代码，需要Jenkins具备自动打包功能，减轻开发工作量 ；

**搭建思路：**
1、开发人员统一使用git来进行代码的上传下载，git需要具备安全功能 ；
2、在jenkins 上面配置maven，将代码拉取下来之后进行打包再发送到tomcat上面进行部署 ；
3、jenkins推送文件到tomcat 对应的目录下之前先停止tomcat，推送完之后启动tomcat ；




>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
>> git 部署配置  >>>>
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

**首先到github上面注册一个账号，创建一个私有仓库并将源代码上传上去。**


**将服务器公钥放到git服务端 ；**

![27.png](https://img.hacpai.com/file/2019/10/27-70088bb2.png)


![28.png](https://img.hacpai.com/file/2019/10/28-a7add000.png)




**jenkins服务器上面需要安装git **

```
[root@jenkins ~]# yum install git -y
[root@jenkins ~]# git --version
    git version 1.8.3.1
```


>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
>> maven 部署配置  >>>>
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

```
[root@jenkins ~]# tar zxvf apache-maven-3.6.2-bin.tar.gz
[root@jenkins ~]# mv apache-maven-3.6.2  /usr/local/maven-3.6.2

[root@jenkins ~]# cd /usr/local/maven-3.6.2/bin/
[root@jenkins bin]# ./mvn -v
    Apache Maven 3.6.2 (40f52333136460af0dc0d7232c0dc0bcf0d9e117; 2019-08-27T11:06:16-04:00)
    Maven home: /usr/local/maven-3.6.2
    Java version: 1.8.0_201, vendor: Oracle Corporation, runtime: /usr/local/jdk1.8.0/jre
    Default locale: en_US, platform encoding: UTF-8
    OS name: "linux", version: "3.10.0-514.el7.x86_64", arch: "amd64", family: "unix"
```


**需要配置好jdk ，参考第一个项目的jdk配置 ；**



>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
>> tomcat 部署配置  >>>>
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


**安装openjdk跟tomcat 并启动 ，使用默认配置即可**

```
[root@tomcat ~]#  yum install java-1.8.0-openjdk  -y
[root@tomcat ~]#  tar zxvf apache-tomcat-8.0.30.tar.gz  
[root@tomcat ~]#  mv apache-tomcat-8.0.30 /usr/local/tomcat

[root@tomcat ~]#  cd /usr/local/tomcat/
[root@tomcat tomcat]# bin/startup.sh
```


**确认服务是否起来**

```
[root@tomcat tomcat]# netstat  -anputl| grep LISTEN
tcp        0      0 0.0.0.0:22              0.0.0.0:*               LISTEN      923/sshd            
tcp        0      0 127.0.0.1:25            0.0.0.0:*               LISTEN      1169/master         
tcp6       0      0 :::8080                 :::*                    LISTEN      2345/java           
tcp6       0      0 :::22                   :::*                    LISTEN      923/sshd            
tcp6       0      0 ::1:25                  :::*                    LISTEN      1169/master         
tcp6       0      0 127.0.0.1:8005          :::*                    LISTEN      2345/java           
tcp6       0      0 :::8009                 :::*                    LISTEN      2345/java           
```

网络上面有很多都是使用tomcat自带的manager 来进行编译后发布的，但是因为这个不太稳定，经常会出现问题，所以这里不做配置。 使用另外一种方式来编译发布 。


>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
>> Jenkins 部署配置  >>>>
>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


**1、配置jenkins 里面的 maven、git、jdk 路径**

![29.png](https://img.hacpai.com/file/2019/10/29-e73f606b.png)


![30.png](https://img.hacpai.com/file/2019/10/30-11fa678d.png)





**2、创建一个maven项目 。**

![31.png](https://img.hacpai.com/file/2019/10/31-c22dfddc.png)



**3、添加jenkins凭证，为git 添加key ，key就是jenkins的私钥。**

![32.png](https://img.hacpai.com/file/2019/10/32-37ecbb0b.png)



此处填写git的地址。
![33.png](https://img.hacpai.com/file/2019/10/33-bde15239.png)




**4、Build处使用pom.xml ， Goals and options 输入  clean install -D maven.test.skip=true ；**

![34.png](https://img.hacpai.com/file/2019/10/34-9487b115.png)



**5、增加构建后操作，选择send build artifacts over ssh 。**

![35.png](https://img.hacpai.com/file/2019/10/35-6b935ee6.png)



**首先停止tomcat， 然后删除掉页面数据 。
第二步将打包好的war包 发送到服务器上并运行**

![36.png](https://img.hacpai.com/file/2019/10/36-5d6c210c.png)





**因为在构建当中出现以下报错信息，主要原因是需要页面需要使用到mysql 以及连接插件**

![37.png](https://img.hacpai.com/file/2019/10/37-36126be9.png)

![38.png](https://img.hacpai.com/file/2019/10/38-826696c7.png)

![39.png](https://img.hacpai.com/file/2019/10/39-2b1977ae.png)





```
mysql> create database zrlog_demo ;
Query OK, 1 row affected (0.00 sec)

mysql> grant all on zrlog_demo.* to zrlog_demo@'%' identified by '123456';
Query OK, 0 rows affected, 1 warning (0.00 sec)

mysql>
mysql> flush privileges;
Query OK, 0 rows affected (0.00 sec)
```




