title: Doveop 技术团队介绍
date: '2019-10-04 14:14:35'
updated: '2019-10-04 15:12:02'
tags: [团队相关]
permalink: /articles/2019/10/04/1570169675695.html
---
![](https://img.hacpai.com/bing/20180907.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# doveop 技术团队 介绍

**技术成员：** mason-roy、duanade、lkk、Fun-ny
**涉及技术分类：** 网络工程相关、系统运维相关
**技术细节分类：** Linux操作系统、Windows操作系统、Web运维、app运维、DBA、虚拟化技术、华为设备、华三设备、思科设备、办公网络搭建维护、等保三级维护等技术
**团队涉及业务：** 免费技术博客分享、技术咨询、收费IT项目解决方案
**联系方式：** QQ/微信:549082161
