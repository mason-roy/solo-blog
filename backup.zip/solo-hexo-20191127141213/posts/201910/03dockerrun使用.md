title: 03 docker run 使用
date: '2019-10-05 14:45:33'
updated: '2019-10-05 14:45:33'
tags: [Docker, 虚拟化]
permalink: /articles/2019/10/05/1570257933280.html
---


## docker run 使用

```bash
    -i   交互式的
    -t   分配终端
    -d  把容器放在后台运行
docker  run  -it    centos   cmd   启动一个交互式的容器，在前台运行
docker  run  -d     centos   cmd   启动一个非交互式的容器，在后台运行
docker  run  -itd   centos   cmd   启动一个交互式的容器，在后台运行
```


**测试**

```bash
docker  run  -it    centos  /bin/bash           成功
docker  run  -d    centos  /bin/bash           失败
docker  run  -itd  centos  /bin/bash           成功

docker  run -it     nginx   nginx                   失败
docker  run -d     nginx   nginx                   失败
docker  run -itd   nginx   nginx                   失败

docker  run -it      nginx   nginx -g "daemon off;"   成功
docker  run -d      nginx   nginx -g "daemon off;"   成功
docker  run -itd    nginx   nginx -g "daemon off;"   成功
```

**交互式的进程启动要使用  it ， 非交互式的使用 d ，交互式的放后台使用  itd**
	启动  bash  的正确姿势  docker run -itd  centos
	启动  nginx 的正确姿势  docker run  -d  -p 80:80  nginx


设置IP伪装访问网络

```bash
[root@room9pc19 docker]# ifconfig
enp2s0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet 172.40.50.119  netmask 255.255.255.0  broadcast 172.40.50.255
        ether 94:de:80:81:e3:53  txqueuelen 1000  (Ethernet)
        RX packets 5947707  bytes 593709850 (566.2 MiB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 12611909  bytes 18788418441 (17.4 GiB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0
```

物理机上查找上网用的网卡

打开路由转发

```bash
sysctl -w net.ipv4.ip_forward=1
```

设置伪装上网

```bash
[root@room9pc19 docker]# iptables -t nat -I POSTROUTING -s 192.168.4.0/24 -o enp2s0 -j MASQUERADE
```


在虚拟机里面设置默认路由

```bash
ip route replace default via 192.168.4.254
```

模拟 docker 端口绑定转发

```bash
iptables -t nat -I PREROUTING -d 192.168.4.10 -p tcp --dport 8080 -i eth0 -j DNAT --to 172.17.0.3:80
docker  run -d -p 8080:80 nginx
```

禁用系统防火墙，在物理机和虚拟机上都需要执行

```bash
systemctl stop firewalld
systemctl mask firewalld
```


