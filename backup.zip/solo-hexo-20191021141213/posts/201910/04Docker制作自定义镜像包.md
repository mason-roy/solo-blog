title: 04 Docker 制作自定义镜像包
date: '2019-10-05 14:52:06'
updated: '2019-10-05 14:52:06'
tags: [Docker, 虚拟化]
permalink: /articles/2019/10/05/1570258326690.html
---


## 制作自定义镜像包的两种方式

        1、创建容器并对容器进行修改，然后打包容器为镜像
        2、使用Dockerfile编排镜像


## 自定义镜像

    1、创建一个容器 docker run -itd centos
    2、进入容器进行修改配置  docker exec -it  容器id  bash
       停止容器，不是必须的
    3、创建镜像并验证 docker  commit  容器id   镜像名称：标签
    4、打包镜像  docker save  镜像名称 > 包名.tar


## 使用 Dockerfile 编排镜像

    给容器配置 yum 源

    查看宿主机的 yum 源配置
    [rhel7]
    name=rhel
    baseurl=ftp://192.168.4.254/rhel7
    enabled=1
    gpgcheck=0
    
	练习： 创建一个容器，配置 yum 源，并且安装  ifconfig 命令

**使用 Dockerfile 编排镜像**

```bash
FROM centos  #基于centos镜像进行编排（如没有就搜索并下载，有就直接使用）
RUN  rm -f /etc/yum.repos.d/*.repo  #运行删除文件命令
ADD  local.repo /etc/yum.repos.d/local.repo   #将当前目录的local.repo文件复制添加到 docker里的指定目录
RUN  yum install net-tools vim-enhanced psmisc iproute -y    #运行安装软件命令
```

**编排命令**

```bash
docker  build  -t  myos:latest  .     #开始编排，使用当前目录下面的Dockerfile文件进行编排，编排后的镜像名为myos，标签为latest
```


**基于 myos 创建 httpd 的镜像**

```bash
FROM myos 
RUN  yum install -y httpd
ENV  EnvironmentFile=/etc/sysconfig/httpd
EXPOSE 80
CMD  ["/usr/sbin/httpd", "-DFOREGROUND"]
```


 **Dockerfile语法格式**

```bash
– FROM:基础镜像
– MAINTAINER:镜像创建者信息
– EXPOSE:开放的端口
– ENV:设置变量
– ADD:复制文件到镜像
– RUN:制作镜像时执行的命令，可以有多个
– WORKDIR:定义容器默认工作目录
– CMD:容器启动时执行的命令，仅可以有一条CMD
– ENTRYPOINT 配置容器启动后执行的命令，并且不可被 docker run 提供的参数覆盖。每个 Dockerfile 中只能有一个 ENTRYPOINT，当指定多个时，只有最后一个起效。
– USER ，USER 命令用于设置运行容器的 UID。# Usage: USER [UID]   ； USER 751
– VOLUME ， VOLUME 命令用于让你的容器访问宿主机上的目录。# Usage: VOLUME ["/dir_1", "/dir_2" ..]  ； VOLUME ["/my_files"]
```




**创建私有仓库**
1  添加配置文件  /etc/docker/daemon.json
```bash
touch  /etc/docker/daemon.json
{
    "insecure-registries" : ["192.168.4.10:5000"]
}
```

重启 docker 服务

```bash
systemctl restart docker
```

2 启动私有仓库

```bash
docker run -d -p 5000:5000 registry
```

3 测试上传镜像到私有仓库

3.1  标记一下哪个镜像要上传

```bash
docker  tag   busybox:latest   镜像服务器ip:5000/busybox:latest
```

3.2 上传镜像

```bash
docker  images
docker  push  镜像服务器ip:5000/busybox:latest
```

4 私有仓库的使用

```bash
查看私有仓库里面的 镜像
http://192.168.4.10:5000/v2/_catalog
查看私有仓库里面镜像的标签
http://192.168.4.10:5000/v2/myos/tags/list
```

5 使用私有仓库运行容器
5.1  添加配置文件  /etc/docker/daemon.json

```bash
touch  /etc/docker/daemon.json
{
    "insecure-registries" : ["192.168.4.10:5000"]
}
```

5.2 重启 docker 服务

```bash
systemctl  restart  docker
```

5.3 启动容器

```bash
docker run -itd 192.168.4.10:5000/myos:latest
docker run -itd 192.168.4.10:5000/myos:python
```

容器的存储与端口映射

存储卷的映射

```bash
docker run -d  -v /var/webroot:/var/www/html   myos:httpd
```
